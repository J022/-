# RMMVPlugin-Triacontane_TW
Translation plugin to Chinese(Traditional) .
本處放置トリアコンタン的翻譯中文插件。<br>
其翻譯與二次發布都有通知作者並授權。<br>
<br>
Twitter [@m03271996](https://twitter.com/m03271996)<br>
Facebook [@reirisgame](https://www.facebook.com/reirisgame/)<br>
Website [@ReIris](https://m03271996.wixsite.com/reirisgame)<br>
Vocus [@ReIris](https://vocus.cc/user/@ReIris?page=1&tab=new)<br>

